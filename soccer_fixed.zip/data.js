// PLAYER ROLES BY POSITION
const PLAYER_ROLES = {
    'GK': {
        'Shot Stopper': { passing: 0.7, distribution: 0.8, positioning: 1.1, reflexes: 1.2 },
        'Sweeper': { passing: 1.1, distribution: 1.0, positioning: 0.9, reflexes: 0.9 },
        'Distributor': { passing: 1.2, distribution: 1.3, positioning: 0.8, reflexes: 0.9 }
    },
    'CB': {
        'Aggressive': { defending: 1.2, tackling: 1.1, positioning: 0.9, passing: 0.9 },
        'Ball Playing': { defending: 0.95, tackling: 0.95, positioning: 0.95, passing: 1.2 },
        'Defensive': { defending: 1.15, tackling: 1.15, positioning: 1.1, passing: 0.85 }
    },
    'LB': {
        'Attacking': { pace: 1.1, crossing: 1.2, defending: 0.85, stamina: 1.05 },
        'Defensive': { pace: 0.95, crossing: 0.85, defending: 1.15, stamina: 1.0 },
        'Balanced': { pace: 1.0, crossing: 1.0, defending: 1.0, stamina: 1.0 }
    },
    'RB': {
        'Attacking': { pace: 1.1, crossing: 1.2, defending: 0.85, stamina: 1.05 },
        'Defensive': { pace: 0.95, crossing: 0.85, defending: 1.15, stamina: 1.0 },
        'Balanced': { pace: 1.0, crossing: 1.0, defending: 1.0, stamina: 1.0 }
    },
    'LWB': {
        'Attacking': { pace: 1.15, crossing: 1.3, defending: 0.8, stamina: 1.1 },
        'Defensive': { pace: 1.0, crossing: 0.9, defending: 1.2, stamina: 1.05 }
    },
    'RWB': {
        'Attacking': { pace: 1.15, crossing: 1.3, defending: 0.8, stamina: 1.1 },
        'Defensive': { pace: 1.0, crossing: 0.9, defending: 1.2, stamina: 1.05 }
    },
    'CM': {
        'Box-to-Box': { pace: 1.0, passing: 1.0, defending: 1.0, stamina: 1.1 },
        'Attacking Midfielder': { pace: 1.05, passing: 1.15, defending: 0.85, stamina: 0.95 },
        'Defensive Midfielder': { pace: 0.95, passing: 0.95, defending: 1.2, stamina: 1.1 },
        'Deep Lying Playmaker': { pace: 0.9, passing: 1.3, defending: 1.05, stamina: 0.95 }
    },
    'CAM': {
        'Playmaker': { pace: 1.05, passing: 1.3, shooting: 1.1, stamina: 0.95 },
        'Goalscorer': { pace: 1.1, passing: 1.0, shooting: 1.2, stamina: 0.9 }
    },
    'LM': {
        'Winger': { pace: 1.2, dribbling: 1.2, crossing: 1.0, defending: 0.8 },
        'Inside Forward': { pace: 1.15, dribbling: 1.1, shooting: 1.15, defending: 0.75 }
    },
    'RM': {
        'Winger': { pace: 1.2, dribbling: 1.2, crossing: 1.0, defending: 0.8 },
        'Inside Forward': { pace: 1.15, dribbling: 1.1, shooting: 1.15, defending: 0.75 }
    },
    'ST': {
        'Poacher': { pace: 1.1, shooting: 1.25, positioning: 1.15, strength: 0.9 },
        'Target Man': { strength: 1.2, heading: 1.2, shooting: 1.0, pace: 0.85 },
        'Complete Forward': { pace: 1.0, shooting: 1.1, dribbling: 1.1, strength: 1.0 }
    },
    'CF': {
        'Poacher': { pace: 1.1, shooting: 1.25, positioning: 1.15, strength: 0.9 },
        'Target Man': { strength: 1.2, heading: 1.2, shooting: 1.0, pace: 0.85 },
        'Complete Forward': { pace: 1.0, shooting: 1.1, dribbling: 1.1, strength: 1.0 }
    }
};

// FUTBIN-STYLE PLAYER DATABASE
const playerDatabase = [
    // Manchester City
    { id: 1, name: 'Ederson', rating: 89, position: 'GK', team: 'Manchester City', pace: 57, shooting: 32, passing: 84, dribbling: 56, defense: 28, physical: 64, potential: 89 },
    { id: 2, name: 'Ruben Dias', rating: 88, position: 'CB', team: 'Manchester City', pace: 75, shooting: 52, passing: 85, dribbling: 65, defense: 89, physical: 84, potential: 89 },
    { id: 3, name: 'Joao Cancelo', rating: 91, position: 'LB', team: 'Manchester City', pace: 87, shooting: 78, passing: 87, dribbling: 87, defense: 85, physical: 78, potential: 92 },
    { id: 4, name: 'Kyle Walker', rating: 88, position: 'RB', team: 'Manchester City', pace: 86, shooting: 63, passing: 80, dribbling: 78, defense: 86, physical: 82, potential: 88 },
    { id: 5, name: 'Manuel Akanji', rating: 85, position: 'CB', team: 'Manchester City', pace: 76, shooting: 54, passing: 82, dribbling: 75, defense: 86, physical: 84, potential: 87 },
    { id: 6, name: 'Rodri', rating: 91, position: 'CM', team: 'Manchester City', pace: 75, shooting: 70, passing: 91, dribbling: 84, defense: 85, physical: 83, potential: 92 },
    { id: 7, name: 'Kalvin Phillips', rating: 78, position: 'CM', team: 'Manchester City', pace: 76, shooting: 65, passing: 78, dribbling: 72, defense: 80, physical: 85, potential: 82 },
    { id: 8, name: 'Jack Grealish', rating: 89, position: 'LM', team: 'Manchester City', pace: 85, shooting: 83, passing: 83, dribbling: 90, defense: 45, physical: 74, potential: 90 },
    { id: 9, name: 'Erling Haaland', rating: 91, position: 'ST', team: 'Manchester City', pace: 84, shooting: 95, passing: 68, dribbling: 80, defense: 45, physical: 94, potential: 93 },
    { id: 10, name: 'Bernardo Silva', rating: 86, position: 'CM', team: 'Manchester City', pace: 82, shooting: 81, passing: 84, dribbling: 89, defense: 60, physical: 65, potential: 88 },
    { id: 11, name: 'Phil Foden', rating: 92, position: 'RM', team: 'Manchester City', pace: 86, shooting: 87, passing: 84, dribbling: 93, defense: 51, physical: 74, potential: 94 },
    { id: 12, name: 'John Stones', rating: 84, position: 'CB', team: 'Manchester City', pace: 74, shooting: 51, passing: 88, dribbling: 78, defense: 84, physical: 81, potential: 85 },

    // Real Madrid
    { id: 13, name: 'Thibaut Courtois', rating: 91, position: 'GK', team: 'Real Madrid', pace: 56, shooting: 28, passing: 60, dribbling: 42, defense: 91, physical: 78, potential: 91 },
    { id: 14, name: 'Sergio Ramos', rating: 89, position: 'CB', team: 'Real Madrid', pace: 78, shooting: 74, passing: 81, dribbling: 76, defense: 91, physical: 88, potential: 89 },
    { id: 15, name: 'Ferland Mendy', rating: 86, position: 'LB', team: 'Real Madrid', pace: 87, shooting: 60, passing: 78, dribbling: 80, defense: 84, physical: 79, potential: 87 },
    { id: 16, name: 'Dani Carvajal', rating: 85, position: 'RB', team: 'Real Madrid', pace: 80, shooting: 65, passing: 82, dribbling: 80, defense: 86, physical: 77, potential: 86 },
    { id: 17, name: 'Antonio Rudiger', rating: 88, position: 'CB', team: 'Real Madrid', pace: 82, shooting: 61, passing: 81, dribbling: 77, defense: 88, physical: 89, potential: 88 },
    { id: 18, name: 'Toni Kroos', rating: 89, position: 'CM', team: 'Real Madrid', pace: 78, shooting: 76, passing: 93, dribbling: 88, defense: 76, physical: 71, potential: 89 },
    { id: 19, name: 'Luka Modric', rating: 88, position: 'CM', team: 'Real Madrid', pace: 81, shooting: 72, passing: 90, dribbling: 89, defense: 78, physical: 74, potential: 88 },
    { id: 20, name: 'Federico Valverde', rating: 88, position: 'CM', team: 'Real Madrid', pace: 86, shooting: 78, passing: 82, dribbling: 84, defense: 79, physical: 84, potential: 90 },
    { id: 21, name: 'Vinicius Jr', rating: 91, position: 'LM', team: 'Real Madrid', pace: 95, shooting: 86, passing: 79, dribbling: 90, defense: 38, physical: 80, potential: 93 },
    { id: 22, name: 'Karim Benzema', rating: 92, position: 'ST', team: 'Real Madrid', pace: 80, shooting: 94, passing: 88, dribbling: 87, defense: 35, physical: 79, potential: 92 },
    { id: 23, name: 'Rodrygo', rating: 87, position: 'RM', team: 'Real Madrid', pace: 89, shooting: 84, passing: 80, dribbling: 88, defense: 38, physical: 73, potential: 90 },
    { id: 24, name: 'Aurelien Tchouameni', rating: 85, position: 'CM', team: 'Real Madrid', pace: 83, shooting: 70, passing: 82, dribbling: 81, defense: 84, physical: 85, potential: 88 },

    // Bayern Munich
    { id: 25, name: 'Manuel Neuer', rating: 89, position: 'GK', team: 'Bayern Munich', pace: 58, shooting: 31, passing: 76, dribbling: 48, defense: 89, physical: 79, potential: 89 },
    { id: 26, name: 'Dayot Upamecano', rating: 85, position: 'CB', team: 'Bayern Munich', pace: 82, shooting: 58, passing: 78, dribbling: 74, defense: 86, physical: 86, potential: 87 },
    { id: 27, name: 'Alphonso Davies', rating: 87, position: 'LB', team: 'Bayern Munich', pace: 92, shooting: 64, passing: 83, dribbling: 86, defense: 82, physical: 80, potential: 90 },
    { id: 28, name: 'Benjamin Pavard', rating: 85, position: 'RB', team: 'Bayern Munich', pace: 81, shooting: 68, passing: 80, dribbling: 78, defense: 84, physical: 81, potential: 86 },
    { id: 29, name: 'Matthijs de Ligt', rating: 87, position: 'CB', team: 'Bayern Munich', pace: 79, shooting: 59, passing: 84, dribbling: 80, defense: 87, physical: 89, potential: 90 },
    { id: 30, name: 'Joshua Kimmich', rating: 89, position: 'CM', team: 'Bayern Munich', pace: 80, shooting: 76, passing: 86, dribbling: 82, defense: 80, physical: 80, potential: 90 },
    { id: 31, name: 'Leon Goretzka', rating: 85, position: 'CM', team: 'Bayern Munich', pace: 82, shooting: 77, passing: 81, dribbling: 81, defense: 77, physical: 85, potential: 87 },
    { id: 32, name: 'Serge Gnabry', rating: 84, position: 'RM', team: 'Bayern Munich', pace: 87, shooting: 85, passing: 80, dribbling: 86, defense: 38, physical: 75, potential: 86 },
    { id: 33, name: 'Sadio Mane', rating: 89, position: 'LM', team: 'Bayern Munich', pace: 86, shooting: 88, passing: 82, dribbling: 85, defense: 45, physical: 80, potential: 90 },
    { id: 34, name: 'Robert Lewandowski', rating: 93, position: 'ST', team: 'Bayern Munich', pace: 82, shooting: 97, passing: 81, dribbling: 86, defense: 35, physical: 84, potential: 93 },
    { id: 35, name: 'Jamal Musiala', rating: 87, position: 'CM', team: 'Bayern Munich', pace: 88, shooting: 82, passing: 84, dribbling: 90, defense: 50, physical: 68, potential: 91 },
    { id: 36, name: 'Thomas Muller', rating: 86, position: 'RM', team: 'Bayern Munich', pace: 78, shooting: 84, passing: 88, dribbling: 82, defense: 55, physical: 76, potential: 86 },

    // Paris Saint-Germain
    { id: 37, name: 'Gianluigi Donnarumma', rating: 89, position: 'GK', team: 'Paris Saint-Germain', pace: 57, shooting: 30, passing: 71, dribbling: 45, defense: 87, physical: 76, potential: 90 },
    { id: 38, name: 'Marquinhos', rating: 88, position: 'CB', team: 'Paris Saint-Germain', pace: 78, shooting: 60, passing: 85, dribbling: 78, defense: 88, physical: 84, potential: 89 },
    { id: 39, name: 'Juan Bernat', rating: 82, position: 'LB', team: 'Paris Saint-Germain', pace: 82, shooting: 65, passing: 80, dribbling: 82, defense: 79, physical: 74, potential: 84 },
    { id: 40, name: 'Achraf Hakimi', rating: 87, position: 'RB', team: 'Paris Saint-Germain', pace: 89, shooting: 78, passing: 79, dribbling: 84, defense: 80, physical: 78, potential: 89 },
    { id: 41, name: 'Sergio Ramos', rating: 86, position: 'CB', team: 'Paris Saint-Germain', pace: 76, shooting: 72, passing: 81, dribbling: 76, defense: 90, physical: 88, potential: 87 },
    { id: 42, name: 'Marco Verratti', rating: 89, position: 'CM', team: 'Paris Saint-Germain', pace: 80, shooting: 68, passing: 90, dribbling: 87, defense: 78, physical: 70, potential: 89 },
    { id: 43, name: 'Danilo Pereira', rating: 83, position: 'CM', team: 'Paris Saint-Germain', pace: 77, shooting: 70, passing: 82, dribbling: 76, defense: 82, physical: 85, potential: 85 },
    { id: 44, name: 'Kylian Mbappe', rating: 95, position: 'ST', team: 'Paris Saint-Germain', pace: 97, shooting: 94, passing: 80, dribbling: 95, defense: 38, physical: 78, potential: 96 },
    { id: 45, name: 'Neymar Jr', rating: 89, position: 'LM', team: 'Paris Saint-Germain', pace: 87, shooting: 85, passing: 87, dribbling: 94, defense: 40, physical: 71, potential: 90 },
    { id: 46, name: 'Lionel Messi', rating: 93, position: 'RM', team: 'Paris Saint-Germain', pace: 85, shooting: 95, passing: 92, dribbling: 95, defense: 38, physical: 65, potential: 93 },
    { id: 47, name: 'Leandro Paredes', rating: 84, position: 'CM', team: 'Paris Saint-Germain', pace: 76, shooting: 68, passing: 84, dribbling: 80, defense: 81, physical: 81, potential: 86 },
    { id: 48, name: 'Presnel Kimpembe', rating: 83, position: 'CB', team: 'Paris Saint-Germain', pace: 78, shooting: 52, passing: 76, dribbling: 72, defense: 83, physical: 82, potential: 85 },

    // Liverpool
    { id: 49, name: 'Alisson', rating: 89, position: 'GK', team: 'Liverpool', pace: 58, shooting: 29, passing: 72, dribbling: 46, defense: 88, physical: 77, potential: 89 },
    { id: 50, name: 'Virgil van Dijk', rating: 90, position: 'CB', team: 'Liverpool', pace: 79, shooting: 62, passing: 87, dribbling: 80, defense: 91, physical: 88, potential: 91 },
    { id: 51, name: 'Andy Robertson', rating: 87, position: 'LB', team: 'Liverpool', pace: 85, shooting: 66, passing: 83, dribbling: 80, defense: 84, physical: 81, potential: 88 },
    { id: 52, name: 'Trent Alexander-Arnold', rating: 88, position: 'RB', team: 'Liverpool', pace: 84, shooting: 74, passing: 89, dribbling: 86, defense: 84, physical: 78, potential: 89 },
    { id: 53, name: 'Ibrahima Konate', rating: 85, position: 'CB', team: 'Liverpool', pace: 82, shooting: 58, passing: 80, dribbling: 76, defense: 85, physical: 86, potential: 87 },
    { id: 54, name: 'Jordan Henderson', rating: 84, position: 'CM', team: 'Liverpool', pace: 78, shooting: 70, passing: 84, dribbling: 78, defense: 79, physical: 82, potential: 85 },
    { id: 55, name: 'Thiago Alcantara', rating: 87, position: 'CM', team: 'Liverpool', pace: 81, shooting: 74, passing: 92, dribbling: 87, defense: 77, physical: 73, potential: 88 },
    { id: 56, name: 'Mohamed Salah', rating: 92, position: 'RM', team: 'Liverpool', pace: 89, shooting: 93, passing: 81, dribbling: 89, defense: 45, physical: 75, potential: 93 },
    { id: 57, name: 'Luis Diaz', rating: 86, position: 'LM', team: 'Liverpool', pace: 86, shooting: 84, passing: 80, dribbling: 88, defense: 42, physical: 76, potential: 89 },
    { id: 58, name: 'Darwin Nunez', rating: 84, position: 'ST', team: 'Liverpool', pace: 86, shooting: 84, passing: 76, dribbling: 80, defense: 40, physical: 88, potential: 88 },
    { id: 59, name: 'Fabinho', rating: 86, position: 'CM', team: 'Liverpool', pace: 78, shooting: 68, passing: 81, dribbling: 78, defense: 85, physical: 86, potential: 87 },
    { id: 60, name: 'Joe Gomez', rating: 82, position: 'CB', team: 'Liverpool', pace: 81, shooting: 54, passing: 76, dribbling: 72, defense: 81, physical: 80, potential: 85 }
];

const championsLeagueTeams = [
    { name: 'Manchester City', players: [1,2,3,4,5,6,7,8,9,10,11,12] },
    { name: 'Real Madrid', players: [13,14,15,16,17,18,19,20,21,22,23,24] },
    { name: 'Bayern Munich', players: [25,26,27,28,29,30,31,32,33,34,35,36] },
    { name: 'Paris Saint-Germain', players: [37,38,39,40,41,42,43,44,45,46,47,48] },
    { name: 'Liverpool', players: [49,50,51,52,53,54,55,56,57,58,59,60] }
];

// GET DEFAULT ROLES FOR POSITIONS
function getDefaultRole(position) {
    const roleMap = {
        'GK': 'Shot Stopper',
        'CB': 'Defensive',
        'LB': 'Balanced',
        'RB': 'Balanced',
        'LWB': 'Attacking',
        'RWB': 'Attacking',
        'CM': 'Box-to-Box',
        'CAM': 'Playmaker',
        'CDM': 'Defensive Midfielder',
        'LM': 'Winger',
        'RM': 'Winger',
        'ST': 'Complete Forward',
        'CF': 'Complete Forward'
    };
    return roleMap[position] || 'Balanced';
}

// GET AVAILABLE ROLES FOR POSITION
function getAvailableRoles(position) {
    return PLAYER_ROLES[position] ? Object.keys(PLAYER_ROLES[position]) : [];
}
