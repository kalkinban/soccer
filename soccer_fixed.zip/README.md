# ⚽ Advanced Soccer Simulation Game

A realistic soccer simulation game with tactical depth, player-stat-based mechanics, and an advanced match engine.

## Features

### 🎮 Core Features
- **Realistic Match Engine**: Physics-based simulation that considers player stats, formation, and tactics
- **Player Database**: 60+ players from top Champions League teams with detailed attributes
- **Formation System**: 5 different formations (4-3-3, 4-2-3-1, 3-5-2, 5-3-2, 4-4-2)
- **Player Roles**: 20+ role types with stat multipliers (Poacher, Deep Lying Playmaker, etc.)
- **Tactical Depth**: Mentality, build-up play, pressing style, and wing play options

### 📊 Match Simulation
- **Stat-Based Gameplay**: Player shooting, passing, defense, and physical stats directly impact match events
- **Formation Impact**: Different formations affect possession, defensive strength, and attacking capability
- **Role Multipliers**: Each player role applies stat multipliers based on tactical role
- **Dynamic Events**: Goals, shots on target, fouls, and yellow cards based on realistic probabilities

### 📈 Match Statistics
- Possession percentage
- Shots and shots on target
- Passes and pass accuracy
- Tackles and fouls
- Real-time event log

### 👥 Team Management
- Select 11 starting players
- Choose 5 bench players
- Assign tactical roles to each player
- Configure team tactics and mentality

## How to Play

1. **Setup Your Team**
   - Select 11 starting players from the player database
   - Choose 5 bench players
   - Assign tactical roles to each player (e.g., Poacher, Deep Lying Playmaker)

2. **Configure Tactics**
   - Choose your formation
   - Set mentality (Defensive, Balanced, Aggressive)
   - Select build-up play style (Long Ball, Mixed, Short Passing)
   - Set pressing intensity (Low, Medium, High)
   - Choose width (Narrow, Balanced, Wide)

3. **Select Opponent**
   - Choose from 5 Champions League teams

4. **Simulate Match**
   - Click "START MATCH"
   - Click "Continue" to progress through the match minute by minute
   - Watch as the match unfolds with realistic simulation

## Match Simulation Details

### How Stats Matter

**Player Attributes** (1-99 scale):
- **Pace**: Affects movement speed and explosive power
- **Shooting**: Determines accuracy and power of shots
- **Passing**: Affects pass completion rate
- **Dribbling**: Determines ability to evade defenders
- **Defense**: Impacts tackling and positioning
- **Physical**: Affects strength and stamina

### Formation Impact

| Formation | Play Style | Defensive | Balanced | Attacking |
|-----------|-----------|-----------|----------|-----------|
| 4-3-3 | Balanced | Medium | High | Medium |
| 4-2-3-1 | Defensive | High | Medium | Low |
| 3-5-2 | Attacking | Low | Medium | High |
| 5-3-2 | Very Defensive | Very High | Low | Low |
| 4-4-2 | Classic | Medium | Medium | Medium |

### Player Roles & Multipliers

**Strikers**:
- **Poacher**: +25% shooting, -10% strength, +15% positioning
- **Target Man**: +20% strength, +20% heading, -15% pace
- **Complete Forward**: Balanced across all stats

**Midfielders**:
- **Deep Lying Playmaker**: +30% passing, -10% pace
- **Box-to-Box**: Balanced performance across all areas
- **Attacking Midfielder**: +30% passing, +15% shooting
- **Defensive Midfielder**: +20% defense, +20% tackling

**Defenders**:
- **Aggressive**: +20% defense, -10% positioning
- **Ball Playing**: +20% passing, -5% defending
- **Defensive**: +15% defense, +15% positioning

### Match Engine Algorithm

1. **Team Strength Calculation**
   - Averages all player attributes
   - Applies role multipliers
   - Considers player positions

2. **Possession Determination**
   - Based on team strength ratio
   - Modified by mentality settings
   - Random variance for realism

3. **Attacking Simulation**
   - Pass success based on player passing stats and build-up style
   - Shot probability based on attacker shooting quality
   - Save probability based on goalkeeper defense stats
   - Goal probability based on shot quality vs save quality

4. **Tactical Adjustments**
   - Mentality affects shot frequency (Aggressive = more shots)
   - Build-up style affects pass success rate
   - Pressing affects defensive intensity
   - Formation affects possession and attacking/defensive balance

## Installation

1. Clone or download this repository
2. Open `index.html` in any modern web browser
3. No dependencies or external APIs required

## Files

- `index.html` - Main game interface
- `styles.css` - All styling and responsive design
- `data.js` - Player database, roles, and Champions League teams
- `app.js` - Game logic, match engine, and simulation

## Technology

- Vanilla JavaScript (ES6+)
- CSS3 with responsive design
- No external dependencies

## Future Enhancements

- Substitution system (mid-match tactical changes)
- Injury system
- Player form/momentum
- Squad chemistry
- Career mode
- Save/load game state
- Multiplayer competitive matches

## License

MIT License - Free to use and modify

## Credits

Inspired by FutBin and FIFA Ultimate Team databases with realistic match engine mechanics.

---

**Enjoy the game!** ⚽🎮
