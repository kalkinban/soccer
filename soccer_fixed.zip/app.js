// GAME STATE
let gameState = {
    userTeam: {
        starting11: [],
        bench: [],
        formation: '4-3-3',
        mentality: 'balanced',
        buildUp: 'mixed',
        pressing: 'medium',
        width: 'balanced',
        playerRoles: {}
    },
    opponentTeam: {
        starting11: [],
        bench: [],
        formation: '4-3-3',
        mentality: 'balanced',
        buildUp: 'mixed',
        pressing: 'medium',
        width: 'balanced',
        playerRoles: {}
    },
    match: {
        minute: 0,
        userGoals: 0,
        opponentGoals: 0,
        possession: 50,
        stats: {
            user: { shots: 0, shotsOnTarget: 0, passes: 0, passAccuracy: 0, tackles: 0, fouls: 0 },
            opponent: { shots: 0, shotsOnTarget: 0, passes: 0, passAccuracy: 0, tackles: 0, fouls: 0 }
        },
        events: [],
        inProgress: false
    }
};

// ========================
// INITIALIZATION
// ========================

function initGame() {
    displayAvailablePlayers();
    displayOpponents();
    updateFormation();
}

function displayAvailablePlayers() {
    const container = document.getElementById('availablePlayers');
    container.innerHTML = playerDatabase.map(player => `
        <div class="bench-player" onclick="selectPlayer(${player.id})">
            <strong>${player.name}</strong> (${player.rating})
            <br><small>${player.position} - ${player.team}</small>
        </div>
    `).join('');
}

function displayOpponents() {
    const select = document.getElementById('opponentSelect');
    select.innerHTML = championsLeagueTeams.map(team => 
        `<option value="${team.name}">${team.name}</option>`
    ).join('');
}

function filterPlayers() {
    const searchTerm = document.getElementById('playerSearch').value.toLowerCase();
    const container = document.getElementById('availablePlayers');
    const filtered = playerDatabase.filter(p => 
        p.name.toLowerCase().includes(searchTerm) || 
        p.team.toLowerCase().includes(searchTerm) ||
        p.position.toLowerCase().includes(searchTerm)
    );
    container.innerHTML = filtered.map(player => `
        <div class="bench-player" onclick="selectPlayer(${player.id})">
            <strong>${player.name}</strong> (${player.rating})
            <br><small>${player.position} - ${player.team}</small>
        </div>
    `).join('');
}

// ========================
// PLAYER SELECTION
// ========================

function selectPlayer(playerId) {
    const player = playerDatabase.find(p => p.id === playerId);
    
    if (gameState.userTeam.starting11.length < 11) {
        gameState.userTeam.starting11.push(player);
        gameState.userTeam.playerRoles[playerId] = getDefaultRole(player.position);
        updateTeamDisplay();
    } else {
        alert('Starting 11 is full. Move a player to bench first.');
    }
}

function moveToB ench(playerId) {
    const playerIndex = gameState.userTeam.starting11.findIndex(p => p.id === playerId);
    if (playerIndex > -1) {
        const player = gameState.userTeam.starting11.splice(playerIndex, 1)[0];
        if (gameState.userTeam.bench.length < 5) {
            gameState.userTeam.bench.push(player);
            updateTeamDisplay();
        }
    }
}

function removeFromBench(playerId) {
    const playerIndex = gameState.userTeam.bench.findIndex(p => p.id === playerId);
    if (playerIndex > -1) {
        gameState.userTeam.bench.splice(playerIndex, 1);
        updateTeamDisplay();
    }
}

function setPlayerRole(playerId, role) {
    gameState.userTeam.playerRoles[playerId] = role;
}

// ========================
// DISPLAY UPDATES
// ========================

function updateTeamDisplay() {
    document.getElementById('starting11Count').textContent = gameState.userTeam.starting11.length;
    document.getElementById('benchCount').textContent = gameState.userTeam.bench.length;

    // Starting 11
    const starting11Container = document.getElementById('starting11');
    starting11Container.innerHTML = gameState.userTeam.starting11.map((player) => `
        <div class="lineup-player">
            <div class="lineup-player-info">
                <div class="lineup-player-name">${player.name}</div>
                <div class="lineup-player-role">${player.position} - ${gameState.userTeam.playerRoles[player.id]}</div>
            </div>
            <div>
                <span class="lineup-player-rating">${player.rating}</span>
                <button onclick="moveToB ench(${player.id})" style="padding: 5px 8px; font-size: 0.75em;">↓</button>
            </div>
        </div>
    `).join('');

    // Bench
    const benchContainer = document.getElementById('bench');
    benchContainer.innerHTML = gameState.userTeam.bench.map(player => `
        <div class="bench-player" onclick="removeFromBench(${player.id})">
            <strong>${player.name}</strong><br>
            <small>${player.position} - ${player.rating}</small>
        </div>
    `).join('');

    updatePlayerRoles();
    displayPitch();
}

function updatePlayerRoles() {
    const rolesSection = document.getElementById('playerRolesSection');
    if (gameState.userTeam.starting11.length === 0) {
        rolesSection.innerHTML = '<small style="color: #999;">Select starting players to assign roles</small>';
        return;
    }

    rolesSection.innerHTML = gameState.userTeam.starting11.map(player => {
        const roles = getAvailableRoles(player.position);
        const currentRole = gameState.userTeam.playerRoles[player.id] || getDefaultRole(player.position);
        
        return `
            <div class="role-selector">
                <label>${player.name} (${player.position})</label>
                <select onchange="setPlayerRole(${player.id}, this.value)">
                    ${roles.map(role => `<option value="${role}" ${role === currentRole ? 'selected' : ''}>${role}</option>`).join('')}
                </select>
            </div>
        `;
    }).join('');
}

function displayPitch() {
    const pitch = document.getElementById('pitch');
    pitch.innerHTML = '';

    const formationMap = {
        '4-3-3': { defenders: 4, midfielders: 3, forwards: 3 },
        '4-2-3-1': { defenders: 4, midfielders: 5, forwards: 1 },
        '3-5-2': { defenders: 3, midfielders: 5, forwards: 2 },
        '5-3-2': { defenders: 5, midfielders: 3, forwards: 2 },
        '4-4-2': { defenders: 4, midfielders: 4, forwards: 2 }
    };

    const layout = formationMap[gameState.userTeam.formation];
    const positions = calculatePositions(layout);

    gameState.userTeam.starting11.forEach((player, idx) => {
        if (idx < positions.length) {
            const pos = positions[idx];
            const slot = document.createElement('div');
            slot.className = 'player-slot user';
            slot.style.left = pos.x + '%';
            slot.style.top = pos.y + '%';
            slot.innerHTML = `
                <div class="player-number">${player.id}</div>
                <div class="player-name">${player.name.split(' ').pop()}</div>
                <div class="player-role">${gameState.userTeam.playerRoles[player.id]}</div>
            `;
            pitch.appendChild(slot);
        }
    });
}

function calculatePositions(layout) {
    const positions = [];
    
    // GK
    positions.push({ x: 50, y: 5 });

    // Defenders
    const defenderGap = 100 / (layout.defenders + 1);
    for (let i = 1; i <= layout.defenders; i++) {
        positions.push({ x: defenderGap * i, y: 22 });
    }

    // Midfielders
    const midfielderGap = 100 / (layout.midfielders + 1);
    for (let i = 1; i <= layout.midfielders; i++) {
        positions.push({ x: midfielderGap * i, y: 50 });
    }

    // Forwards
    const forwardGap = 100 / (layout.forwards + 1);
    for (let i = 1; i <= layout.forwards; i++) {
        positions.push({ x: forwardGap * i, y: 75 });
    }

    return positions;
}

function updateFormation() {
    gameState.userTeam.formation = document.getElementById('formationSelect').value;
    document.getElementById('formationDisplay').textContent = gameState.userTeam.formation;
    displayPitch();
}

function switchTab(tabName, tabIndex) {
    const contents = document.querySelectorAll('.tab-content');
    const buttons = document.querySelectorAll('.tab-button');
    contents.forEach(c => c.classList.remove('active'));
    buttons.forEach(b => b.classList.remove('active'));
    document.getElementById(tabName).classList.add('active');
    buttons[tabIndex].classList.add('active');
}

// ========================
// MATCH START & VALIDATION
// ========================

function startMatch() {
    // Validation
    if (gameState.userTeam.starting11.length < 11) {
        alert('Select 11 starting players');
        return;
    }
    if (gameState.userTeam.bench.length < 5) {
        alert('Select 5 bench players');
        return;
    }

    // Save tactics
    gameState.userTeam.mentality = document.getElementById('mentality').value;
    gameState.userTeam.buildUp = document.getElementById('buildUp').value;
    gameState.userTeam.pressing = document.getElementById('pressing').value;
    gameState.userTeam.width = document.getElementById('width').value;

    // Setup opponent
    const opponentTeamName = document.getElementById('opponentSelect').value;
    const opponentTeamData = championsLeagueTeams.find(t => t.name === opponentTeamName);
    gameState.opponentTeam.starting11 = opponentTeamData.players.slice(0, 11).map(id => playerDatabase.find(p => p.id === id));
    
    // Auto-assign opponent roles
    gameState.opponentTeam.starting11.forEach(player => {
        gameState.opponentTeam.playerRoles[player.id] = getDefaultRole(player.position);
    });

    // Initialize match
    gameState.match.minute = 0;
    gameState.match.userGoals = 0;
    gameState.match.opponentGoals = 0;
    gameState.match.possession = 50;
    gameState.match.stats = {
        user: { shots: 0, shotsOnTarget: 0, passes: 0, passAccuracy: 0, tackles: 0, fouls: 0 },
        opponent: { shots: 0, shotsOnTarget: 0, passes: 0, passAccuracy: 0, fouls: 0 }
    };
    gameState.match.events = [];
    gameState.match.inProgress = true;

    // Update UI
    document.getElementById('setupMessage').style.display = 'none';
    document.getElementById('matchContainer').style.display = 'block';
    document.getElementById('matchStats').style.display = 'block';
    document.getElementById('setupMessage2').style.display = 'none';
    document.getElementById('startBtn').disabled = true;
    document.getElementById('continueBtn').style.display = 'block';

    displayPitch();
    simulateMinute();
}

// ========================
// REALISTIC MATCH ENGINE
// ========================

function calculateTeamStrength(team, isUser) {
    const tactics = isUser ? gameState.userTeam : gameState.opponentTeam;
    const roles = isUser ? gameState.userTeam.playerRoles : gameState.opponentTeam.playerRoles;

    let totalStrength = 0;
    team.forEach(player => {
        let playerStrength = (player.pace + player.passing + player.shooting + player.dribbling + player.defense + player.physical) / 6;
        
        // Apply role multipliers
        const position = player.position;
        const role = roles[player.id];
        if (PLAYER_ROLES[position] && PLAYER_ROLES[position][role]) {
            const roleMultipliers = PLAYER_ROLES[position][role];
            let roleBoost = 0;
            Object.values(roleMultipliers).forEach(mult => {
                roleBoost += (mult - 1) * 5;
            });
            playerStrength += roleBoost;
        }
        
        totalStrength += playerStrength;
    });

    return totalStrength / team.length;
}

function calculatePossession() {
    const userStrength = calculateTeamStrength(gameState.userTeam.starting11, true);
    const opponentStrength = calculateTeamStrength(gameState.opponentTeam.starting11, false);
    
    let possession = 50 * (userStrength / (userStrength + opponentStrength));
    
    // Mentality impact
    const mentalityBonus = {
        'defensive': -5,
        'balanced': 0,
        'aggressive': 5
    };
    possession += mentalityBonus[gameState.userTeam.mentality] || 0;
    
    return Math.max(30, Math.min(70, possession));
}

function simulateMinute() {
    gameState.match.minute += 1;

    if (gameState.match.minute > 90) {
        endMatch();
        return;
    }

    // Update possession for this minute
    gameState.match.possession = calculatePossession();

    // Determine who has possession
    const userHasPossession = Math.random() * 100 < gameState.match.possession;

    if (userHasPossession) {
        simulateUserPossession();
    } else {
        simulateOpponentPossession();
    }

    updateMatchDisplay();
}

function simulateUserPossession() {
    const buildUpBonus = {
        'short': 1.2,
        'mixed': 1.0,
        'long': 0.8
    };

    const passSuccessRate = (70 + (gameState.userTeam.starting11.reduce((sum, p) => sum + p.passing, 0) / gameState.userTeam.starting11.length) * 0.3) * buildUpBonus[gameState.userTeam.buildUp];
    
    gameState.match.stats.user.passes += Math.floor(Math.random() * 4) + 1;
    gameState.match.stats.user.passAccuracy = Math.min(100, passSuccessRate + Math.random() * 5);

    // Chance of shot
    const attackQuality = gameState.userTeam.starting11
        .filter(p => ['ST', 'CF', 'LM', 'RM', 'CAM'].includes(p.position))
        .reduce((sum, p) => sum + (p.shooting + p.dribbling) / 2, 0) / 3;

    const mentorityMultiplier = {
        'defensive': 0.5,
        'balanced': 1.0,
        'aggressive': 1.5
    };

    const shotChance = (attackQuality * 0.8) * mentorityMultiplier[gameState.userTeam.mentality];

    if (Math.random() * 100 < shotChance) {
        simulateUserShot();
    }
}

function simulateOpponentPossession() {
    gameState.match.stats.opponent.passes += Math.floor(Math.random() * 4) + 1;
    gameState.match.stats.opponent.passAccuracy = 75 + Math.random() * 10;

    const attackQuality = gameState.opponentTeam.starting11
        .filter(p => ['ST', 'CF', 'LM', 'RM', 'CAM'].includes(p.position))
        .reduce((sum, p) => sum + (p.shooting + p.dribbling) / 2, 0) / 3;

    if (Math.random() * 100 < attackQuality * 0.6) {
        simulateOpponentShot();
    }
}

function simulateUserShot() {
    gameState.match.stats.user.shots += 1;

    const userAttackers = gameState.userTeam.starting11.filter(p => ['ST', 'CF', 'LM', 'RM', 'CAM'].includes(p.position));
    const shooter = userAttackers[Math.floor(Math.random() * userAttackers.length)];
    
    if (!shooter) return;

    const shootingQuality = (shooter.shooting + (Math.random() * 20 - 10)) / 100;
    const opponentGK = gameState.opponentTeam.starting11[0];
    const saveQuality = opponentGK.defense / 100;

    if (shootingQuality > saveQuality) {
        gameState.match.stats.user.shotsOnTarget += 1;
        
        if (shootingQuality > saveQuality + 0.2) {
            gameState.match.userGoals += 1;
            const role = gameState.userTeam.playerRoles[shooter.id];
            addMatchEvent(`⚽ GOAL! ${shooter.name} (${role}) - ${gameState.match.minute}'`, 'goal');
        } else {
            addMatchEvent(`🔫 Shot on target from ${shooter.name} - ${gameState.match.minute}'`, 'chance');
        }
    } else {
        addMatchEvent(`❌ ${shooter.name} shoots but it goes wide - ${gameState.match.minute}'`, 'miss');
    }
}

function simulateOpponentShot() {
    gameState.match.stats.opponent.shots += 1;

    const opponentAttackers = gameState.opponentTeam.starting11.filter(p => ['ST', 'CF', 'LM', 'RM', 'CAM'].includes(p.position));
    const shooter = opponentAttackers[Math.floor(Math.random() * opponentAttackers.length)];
    
    if (!shooter) return;

    const shootingQuality = (shooter.shooting + (Math.random() * 20 - 10)) / 100;
    const userGK = gameState.userTeam.starting11[0];
    const saveQuality = userGK.defense / 100;

    if (shootingQuality > saveQuality) {
        gameState.match.stats.opponent.shotsOnTarget += 1;
        
        if (shootingQuality > saveQuality + 0.2) {
            gameState.match.opponentGoals += 1;
            addMatchEvent(`⚽ GOAL! ${shooter.name} scores! - ${gameState.match.minute}'`, 'goal');
        } else {
            addMatchEvent(`🔫 ${shooter.name} shoots but it's saved - ${gameState.match.minute}'`, 'chance');
        }
    } else {
        addMatchEvent(`❌ ${shooter.name} shoots but it goes wide - ${gameState.match.minute}'`, 'miss');
    }
}

function addMatchEvent(text, type = 'normal') {
    gameState.match.events.push({ text, type, minute: gameState.match.minute });
    if (gameState.match.events.length > 20) {
        gameState.match.events.shift();
    }
}

function updateMatchDisplay() {
    document.getElementById('matchMinute').textContent = gameState.match.minute;
    document.getElementById('scoreDisplay').textContent = `${gameState.match.userGoals} - ${gameState.match.opponentGoals}`;
    document.getElementById('possession').textContent = Math.round(gameState.match.possession) + '%';
    document.getElementById('shots').textContent = `${gameState.match.stats.user.shots} - ${gameState.match.stats.opponent.shots}`;
    document.getElementById('passes').textContent = `${gameState.match.stats.user.passes} - ${gameState.match.stats.opponent.passes}`;
    document.getElementById('passAcc').textContent = `${Math.round(gameState.match.stats.user.passAccuracy)}% - ${Math.round(gameState.match.stats.opponent.passAccuracy)}%`;
    document.getElementById('tackles').textContent = `${gameState.match.stats.user.tackles} - ${gameState.match.stats.opponent.tackles}`;
    document.getElementById('fouls').textContent = `${gameState.match.stats.user.fouls} - ${gameState.match.stats.opponent.fouls}`;

    const eventsContainer = document.getElementById('matchEvents');
    eventsContainer.innerHTML = gameState.match.events.map(event => 
        `<div class="event ${event.type}">${event.text}</div>`
    ).join('');
    eventsContainer.scrollTop = eventsContainer.scrollHeight;
}

function continueMatch() {
    simulateMinute();
}

function endMatch() {
    gameState.match.inProgress = false;
    document.getElementById('continueBtn').style.display = 'none';
    
    const result = gameState.match.userGoals > gameState.match.opponentGoals 
        ? '🎉 YOU WON!' 
        : gameState.match.userGoals < gameState.match.opponentGoals 
        ? '😞 YOU LOST' 
        : '🤝 DRAW';

    addMatchEvent(`Match Ended: ${result}`);
    updateMatchDisplay();
}

// ========================
// INITIALIZATION
// ========================

window.onload = initGame;
